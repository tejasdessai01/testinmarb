'use client'

import { useEffect, useState } from 'react'
import { useRouter, useParams } from 'next/navigation'
import { MrbCard, MrbButton, MrbTypography, MrbForm } from '@/designSystem'
import { User, UserApi } from '@/domain/user'

import { Account, AccountApi } from '@/domain/account'
import {MrbToast} from '@/designSystem'
import { useAuthentication } from '@/modules/authentication'
import { DateLibrary } from '@/libraries/date'
import { AiApi } from '@/domain/ai'
import { PageLayout } from '@/layouts/Page.layout'

export default function AddNewAccountPage() {
  const router = useRouter()
  const authentication = useAuthentication()
  const toast = MrbToast.useToast()
  const userId = authentication.user?.id

  const [isLoading, setLoading] = useState<boolean>(false)

  const handleSubmit = async (values) => {
    if (!userId) {
      toast.error('User not found')
      return
    }

    setLoading(true)
    try {
      await AccountApi.createOneByUserId(userId, values)
      toast.success('Account successfully created')
      router.push('/dashboard')
    } catch (error) {
      toast.error('Failed to create account')
    } finally {
      setLoading(false)
    }
  }

  return (
    <PageLayout layout="narrow">
      <MrbTypography variant="h1">Create Account</MrbTypography>
      <MrbCard size="full-width" className="m-2">
        <MrbCard.Body>
          <MrbForm
            onSubmit={handleSubmit}
            inputs={[
              {
                key: 'accountType',
                label: 'Account Type',
                type: 'select',
                options: [
                  { label: 'Checking', value: 'checking' },
                  { label: 'Savings', value: 'savings' },
                  { label: 'Personal', value: 'personal' },
                  { label: 'Business', value: 'business' },
                ],
              },
              {
                key: 'balance',
                label: 'Initial Balance',
                type: 'number',
              },
            ]}
          >
            <MrbButton variant="primary" type="submit" isLoading={isLoading}>
              Create
            </MrbButton>
          </MrbForm>
        </MrbCard.Body>
      </MrbCard>
    </PageLayout>
  )
}