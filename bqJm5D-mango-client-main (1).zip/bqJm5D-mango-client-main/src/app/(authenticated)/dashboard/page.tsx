'use client'

import { useEffect, useState } from 'react'
import { useRouter, useParams } from 'next/navigation'
import { MrbCard, MrbDescription, MrbTable, MrbLoader, MrbTypography, MrbDescriptionList } from '@/designSystem'
import { User, UserApi } from '@/domain/user'

import { Account, AccountApi } from '@/domain/account'
import { Transaction, TransactionApi } from '@/domain/transaction'
import { Investment, InvestmentApi } from '@/domain/investment'
import { Stock, StockApi } from '@/domain/stock'
import {MrbToast} from '@/designSystem'
import { useAuthentication } from '@/modules/authentication'
import { DateLibrary } from '@/libraries/date'
import { AiApi } from '@/domain/ai'
import { PageLayout } from '@/layouts/Page.layout'

export default function DashboardPage() {
  const router = useRouter()
  const authentication = useAuthentication()
  const userId = authentication.user?.id

  const [isLoading, setLoading] = useState<boolean>(true)
  const [totalBalance, setTotalBalance] = useState<number>(0)
  const [transactions, setTransactions] = useState([])
  const [investments, setInvestments] = useState([])
  const [stocks, setStocks] = useState([])

  useEffect(() => {
    if (userId) {
      Promise.all([
        AccountApi.findManyByUserId(userId, { includes: ['transactions'] }),
        InvestmentApi.findManyByUserId(userId, { includes: ['stocks'] }),
      ]).then(([accounts, investments]) => {
        const totalBalance = accounts.reduce((acc, account) => acc + (account.balance || 0), 0)
        const transactions = accounts.flatMap(account => account.transactions || []).slice(0, 50)
        const stocks = investments.flatMap(investment => investment.stocks || [])

        setTotalBalance(totalBalance)
        setTransactions(transactions)
        setInvestments(investments)
        setStocks(stocks)
        setLoading(false)
      })
    }
  }, [userId])

  return (
    <PageLayout layout="narrow">
      {isLoading && <MrbLoader size="large" isExpanded />}

      {!isLoading && (
        <>
          <MrbCard>
            <MrbCard.Body>
              <MrbTypography variant="h1">Financial Dashboard</MrbTypography>
              <MrbDescriptionList>
                <MrbDescriptionList orientation="horizontal" columns={2}>
                  <MrbTypography variant="h3">Total Balance</MrbTypography>
                  <MrbTypography variant="primary">${totalBalance}</MrbTypography>
                </MrbDescriptionList>
              </MrbDescriptionList>
            </MrbCard.Body>
          </MrbCard>

          <MrbCard>
            <MrbCard.Header>Last 50 Transactions</MrbCard.Header>
            <MrbCard.Body>
              <MrbTable>
                <MrbTable.Head>
                  <MrbTable.HeadRow>
                    <MrbTable.HeadColumn>Description</MrbTable.HeadColumn>
                    <MrbTable.HeadColumn>Amount</MrbTable.HeadColumn>
                    <MrbTable.HeadColumn>Date</MrbTable.HeadColumn>
                  </MrbTable.HeadRow>
                </MrbTable.Head>
                <MrbTable.Body>
                  {transactions.map(transaction => (
                    <MrbTable.Row key={transaction.id} onClick={() => router.push('/transactions')}>
                      <MrbTable.Column>{transaction.description}</MrbTable.Column>
                      <MrbTable.Column>${transaction.amount}</MrbTable.Column>
                      <MrbTable.Column>{transaction.date}</MrbTable.Column>
                    </MrbTable.Row>
                  ))}
                </MrbTable.Body>
              </MrbTable>
            </MrbCard.Body>
          </MrbCard>

          <MrbCard>
            <MrbCard.Header>Investment Summary</MrbCard.Header>
            <MrbCard.Body>
              {investments.map(investment => (
                <MrbDescriptionList key={investment.id} onClick={() => router.push('/investments')}>
                  <MrbTypography variant="h3">{investment.investmentType}</MrbTypography>
                  <MrbTypography variant="primary">Balance: ${investment.balance}</MrbTypography>
                </MrbDescriptionList>
              ))}
              <MrbTable>
                <MrbTable.Head>
                  <MrbTable.HeadRow>
                    <MrbTable.HeadColumn>Stock</MrbTable.HeadColumn>
                    <MrbTable.HeadColumn>Unit Value</MrbTable.HeadColumn>
                    <MrbTable.HeadColumn>Quantity</MrbTable.HeadColumn>
                    <MrbTable.HeadColumn>Total Value</MrbTable.HeadColumn>
                  </MrbTable.HeadRow>
                </MrbTable.Head>
                <MrbTable.Body>
                  {stocks.map(stock => (
                    <MrbTable.Row key={stock.id} onClick={() => router.push('/stocks')}>
                      <MrbTable.Column>{stock.symbol}</MrbTable.Column>
                      <MrbTable.Column>${stock.unitValue}</MrbTable.Column>
                      <MrbTable.Column>{stock.quantity}</MrbTable.Column>
                      <MrbTable.Column>${stock.unitValue! * stock.quantity!}</MrbTable.Column>
                    </MrbTable.Row>
                  ))}
                </MrbTable.Body>
              </MrbTable>
            </MrbCard.Body>
          </MrbCard>
        </>
      )}
    </PageLayout>
  )
}