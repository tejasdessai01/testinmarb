'use client'

import { useEffect, useState } from 'react'
import { useRouter, useParams } from 'next/navigation'
import { MrbCard, MrbButton, MrbTypography, MrbForm } from '@/designSystem'
import { User, UserApi } from '@/domain/user'

import { Investment, InvestmentApi } from '@/domain/investment'
import {MrbToast} from '@/designSystem'
import { useAuthentication } from '@/modules/authentication'
import { DateLibrary } from '@/libraries/date'
import { AiApi } from '@/domain/ai'
import { PageLayout } from '@/layouts/Page.layout'

export default function AddNewInvestmentPage() {
  const router = useRouter()
  const authentication = useAuthentication()
  const toast = MrbToast.useToast()
  const userId = authentication.user?.id

  const [isLoading, setLoading] = useState<boolean>(false)

  const handleSubmit = async (values) => {
    setLoading(true)
    try {
      await InvestmentApi.createOneByUserId(userId, values)
      toast.success('Investment successfully added.')
      router.push('/investments')
    } catch (error) {
      toast.error('Failed to add investment.')
    }
    setLoading(false)
  }

  const handleAddAnother = () => {
    router.push('/investment/create')
  }

  return (
    <PageLayout layout="narrow">
      <MrbTypography variant="h1">Add New Investment</MrbTypography>
      <MrbCard size="full-width" className="m-2">
        <MrbCard.Body>
          <MrbForm
            onSubmit={handleSubmit}
            inputs={[
              {
                key: 'investmentType',
                type: 'text',
                label: 'Type of Investment',
              },
              {
                key: 'balance',
                type: 'number',
                label: 'Initial Balance',
              },
            ]}
          >
            <MrbButton variant="primary" type="submit" isLoading={isLoading}>
              Create
            </MrbButton>
          </MrbForm>
          <MrbButton variant="default" onClick={handleAddAnother} className="mt-2">
            Add Another Investment
          </MrbButton>
        </MrbCard.Body>
      </MrbCard>
    </PageLayout>
  )
}