'use client'

import { useEffect, useState } from 'react'
import { useRouter, useParams } from 'next/navigation'
import { MrbCard, MrbButton, MrbTypography, MrbForm } from '@/designSystem'
import { Investment, InvestmentApi } from '@/domain/investment'
import { Stock, StockApi } from '@/domain/stock'
import {MrbToast} from '@/designSystem'
import { useAuthentication } from '@/modules/authentication'
import { DateLibrary } from '@/libraries/date'
import { AiApi } from '@/domain/ai'
import { PageLayout } from '@/layouts/Page.layout'

export default function AddNewStockPage() {
  const router = useRouter()
  const authentication = useAuthentication()
  const toast = MrbToast.useToast()
  const investmentId = authentication.user?.investments?.[0]?.id

  const [isLoading, setLoading] = useState<boolean>(false)

  const handleSubmit = async values => {
    if (!investmentId) {
      toast.error('Investment ID is missing.')
      return
    }

    setLoading(true)
    try {
      await StockApi.createOneByInvestmentId(investmentId, values)
      toast.success('Stock successfully added to your portfolio.')
      router.push('/investments')
    } catch (error) {
      toast.error('An error occurred while adding the stock.')
    } finally {
      setLoading(false)
    }
  }

  return (
    <PageLayout layout="narrow">
      <MrbTypography variant="h1">Add New Stock</MrbTypography>
      <MrbCard size="full-width" className="m-2">
        <MrbCard.Body>
          <MrbForm
            onSubmit={handleSubmit}
            inputs={[
              {
                key: 'symbol',
                type: 'text',
                label: 'Stock Symbol',
              },
              {
                key: 'unitValue',
                type: 'number',
                label: 'Unit Value',
              },
              {
                key: 'quantity',
                type: 'number',
                label: 'Quantity',
              },
            ]}
          >
            <MrbButton variant="primary" type="submit" isLoading={isLoading}>
              Create
            </MrbButton>
          </MrbForm>
        </MrbCard.Body>
      </MrbCard>
    </PageLayout>
  )
}