'use client'

import { useEffect, useState } from 'react'
import { useRouter, useParams } from 'next/navigation'
import { MrbTable, MrbButton, MrbLoader } from '@/designSystem'
import { User, UserApi } from '@/domain/user'

import { Investment, InvestmentApi } from '@/domain/investment'
import { Stock, StockApi } from '@/domain/stock'
import {MrbToast} from '@/designSystem'
import { useAuthentication } from '@/modules/authentication'
import { DateLibrary } from '@/libraries/date'
import { AiApi } from '@/domain/ai'
import { PageLayout } from '@/layouts/Page.layout'

export default function MyStocksPage() {
  const router = useRouter()
  const authentication = useAuthentication()
  const toast = MrbToast.useToast()
  const userId = authentication.user?.id

  const [isLoading, setLoading] = useState<boolean>(true)
  const [items, setItems] = useState<Investment[]>([])

  useEffect(() => {
    if (userId) {
      InvestmentApi.findManyByUserId(userId, { includes: ['stocks'] })
        .then(setItems)
        .catch(error => toast.error('Failed to fetch investments.'))
        .finally(() => setLoading(false))
    }
  }, [userId])

  const handleViewStock = (stockId: string) => {
    router.push('/stocks/' + stockId)
  }

  const handleAddNewStock = () => {
    router.push('/stock/create')
  }

  return (
    <PageLayout layout="narrow">
      {isLoading && <MrbLoader size="large" isExpanded />}
      {!isLoading && (
        <>
          <MrbButton onClick={handleAddNewStock}>Add New Stock</MrbButton>
          <MrbTable>
            <MrbTable.Head>
              <MrbTable.HeadRow>
                <MrbTable.HeadColumn>Symbol</MrbTable.HeadColumn>
                <MrbTable.HeadColumn>Unit Value</MrbTable.HeadColumn>
                <MrbTable.HeadColumn>Quantity</MrbTable.HeadColumn>
                <MrbTable.HeadColumn>Total Value</MrbTable.HeadColumn>
                <MrbTable.HeadColumn>Actions</MrbTable.HeadColumn>
              </MrbTable.HeadRow>
            </MrbTable.Head>
            <MrbTable.Body>
              {items?.flatMap(investment => investment.stocks?.map(stock => (
                <MrbTable.Row key={stock.id}>
                  <MrbTable.Column>{stock.symbol}</MrbTable.Column>
                  <MrbTable.Column>{stock.unitValue}</MrbTable.Column>
                  <MrbTable.Column>{stock.quantity}</MrbTable.Column>
                  <MrbTable.Column>{stock.unitValue && stock.quantity ? (stock.unitValue * stock.quantity).toFixed(2) : ''}</MrbTable.Column>
                  <MrbTable.Column>
                    <MrbButton onClick={() => handleViewStock(stock.id)}>View</MrbButton>
                  </MrbTable.Column>
                </MrbTable.Row>
              )))}
            </MrbTable.Body>
          </MrbTable>
        </>
      )}
    </PageLayout>
  )
}