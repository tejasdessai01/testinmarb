'use client'

import { useEffect, useState } from 'react'
import { useRouter, useParams } from 'next/navigation'
import { MrbCard, MrbButton, MrbTypography, MrbForm } from '@/designSystem'
import { User, UserApi } from '@/domain/user'

import { Account, AccountApi } from '@/domain/account'
import { Transaction, TransactionApi } from '@/domain/transaction'
import {MrbToast} from '@/designSystem'
import { useAuthentication } from '@/modules/authentication'
import { DateLibrary } from '@/libraries/date'
import { AiApi } from '@/domain/ai'
import { PageLayout } from '@/layouts/Page.layout'

export default function RecordNewTransactionPage() {
  const router = useRouter()
  const authentication = useAuthentication()
  const toast = MrbToast.useToast()
  const userId = authentication.user?.id

  const [isLoading, setLoading] = useState<boolean>(false)
  const [accounts, setAccounts] = useState([])

  useEffect(() => {
    if (userId) {
      AccountApi.findManyByUserId(userId).then(setAccounts)
    }
  }, [userId])

  const handleSubmit = async (values) => {
    setLoading(true)
    try {
      const transaction = await TransactionApi.createOneByAccountId(values.accountId, {
        amount: values.amount,
        transactionType: values.transactionType,
        description: values.description,
        date: values.date,
      })
      toast.success(`Transaction ${transaction.transactionType} of $${transaction.amount} was successfully recorded.`)
      router.push('/transactions')
    } catch (error) {
      toast.error('An error occurred while recording the transaction.')
    }
    setLoading(false)
  }

  return (
    <PageLayout layout="narrow">
      <MrbTypography variant="h1">Record New Transaction</MrbTypography>
      <MrbCard size="full-width" className="m-2">
        <MrbCard.Body>
          <MrbForm
            onSubmit={handleSubmit}
            inputs={[
              {
                key: 'amount',
                type: 'number',
                label: 'Amount',
              },
              {
                key: 'transactionType',
                type: 'select',
                label: 'Transaction Type',
                options: [
                  { label: 'Deposit', value: 'Deposit' },
                  { label: 'Withdrawal', value: 'Withdrawal' },
                ],
              },
              {
                key: 'description',
                type: 'textarea',
                label: 'Description',
              },
              {
                key: 'date',
                type: 'date',
                label: 'Date',
              },
              {
                key: 'accountId',
                type: 'select',
                label: 'Account',
                options: accounts.map(account => ({
                  label: account.accountType,
                  value: account.id,
                })),
              },
            ]}
          >
            <MrbButton variant="primary" type="submit" isLoading={isLoading}>
              Record Transaction
            </MrbButton>
          </MrbForm>
        </MrbCard.Body>
      </MrbCard>
    </PageLayout>
  )
}