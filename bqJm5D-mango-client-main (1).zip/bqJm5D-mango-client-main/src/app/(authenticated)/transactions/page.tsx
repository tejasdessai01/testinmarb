'use client'

import { useEffect, useState } from 'react'
import { useRouter, useParams } from 'next/navigation'
import { MrbDescription, MrbCol, MrbEmptyState, MrbLink, MrbList, MrbLoader, MrbRow, MrbDescriptionList } from '@/designSystem'
import { User, UserApi } from '@/domain/user'

import { Account, AccountApi } from '@/domain/account'
import { Transaction, TransactionApi } from '@/domain/transaction'
import { Investment, InvestmentApi } from '@/domain/investment'
import { Stock, StockApi } from '@/domain/stock'
import {MrbToast} from '@/designSystem'
import { useAuthentication } from '@/modules/authentication'
import { DateLibrary } from '@/libraries/date'
import { AiApi } from '@/domain/ai'
import { PageLayout } from '@/layouts/Page.layout'

export default function RecentTransactionsPage() {
  const router = useRouter()
  const authentication = useAuthentication()
  const toast = MrbToast.useToast()
  const userId = authentication.user?.id

  const [isLoading, setLoading] = useState<boolean>(true)
  const [items, setItems] = useState([])

  useEffect(() => {
    if (userId) {
      AccountApi.findManyByUserId(userId, { includes: ['transactions'] })
        .then(accounts => {
          const transactions = accounts
            .flatMap(account => account.transactions || [])
            .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime())
            .slice(0, 50)
          setItems(transactions)
        })
        .catch(error => {
          toast.error('Failed to fetch transactions.')
        })
        .finally(() => {
          setLoading(false)
        })
    }
  }, [userId])

  return (
    <PageLayout layout="narrow">
      {isLoading && <MrbLoader size="large" isExpanded />}

      {!isLoading && (
        <>
          <MrbRow gap={2} className="mrb-fill-x">
            <MrbLink to="/dashboard">Dashboard</MrbLink>
            <MrbLink to="/investments">Investment Overview</MrbLink>
            <MrbLink to="/stocks">My Stocks</MrbLink>
            <MrbLink to="/transaction/create">Record New Transaction</MrbLink>
          </MrbRow>

          {items?.length === 0 && (
            <MrbEmptyState>
              There are no transactions to be displayed.
            </MrbEmptyState>
          )}

          <MrbList divider={true}>
            {items?.map(transaction => (
              <MrbList.Item
                key={transaction.id}
                onClick={() => {
                  router.push(`/transactions/${transaction.id}`)
                }}
              >
                <MrbRow gap={2} className="mrb-fill-x">
                  <MrbCol xs="fill">
                    <MrbDescriptionList orientation="horizontal">
                      <MrbDescription>
                        <MrbDescription.Label>Amount</MrbDescription.Label>
                        <MrbDescription.Value>
                          {transaction.amount}
                        </MrbDescription.Value>
                      </MrbDescription>
                      <MrbDescription>
                        <MrbDescription.Label>Type</MrbDescription.Label>
                        <MrbDescription.Value>
                          {transaction.transactionType}
                        </MrbDescription.Value>
                      </MrbDescription>
                      <MrbDescription>
                        <MrbDescription.Label>Description</MrbDescription.Label>
                        <MrbDescription.Value>
                          {transaction.description}
                        </MrbDescription.Value>
                      </MrbDescription>
                      <MrbDescription>
                        <MrbDescription.Label>Date</MrbDescription.Label>
                        <MrbDescription.Value>
                          {transaction.date}
                        </MrbDescription.Value>
                      </MrbDescription>
                    </MrbDescriptionList>
                  </MrbCol>
                </MrbRow>
              </MrbList.Item>
            ))}
          </MrbList>
        </>
      )}
    </PageLayout>
  )
}