'use client'

import { MrbDivider } from '@/designSystem'

export default function DividerShow() {
  return (
    <>
      <p>One text</p>
      <MrbDivider />
      <p>Two Text</p>
    </>
  )
}
