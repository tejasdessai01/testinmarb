export interface MrbDescriptionTheme {
  label?: {
    color?: string
    textTransform?: string
    fontSize?: string
    fontWeight?: string
  }

  value?: {
    color?: string
    textTransform?: string
    fontSize?: string
    fontWeight?: string
  }
}
