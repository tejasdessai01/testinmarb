export interface MrbFormLabel {
  textSize?: string
  color?: string

  optional?: {
    textSize?: string
    color?: string
  }

  indication?: {
    textSize?: string
    color?: string
  }

  variantDanger?: {
    color?: string
  }
}
