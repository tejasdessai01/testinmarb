export interface MrbDescriptionTheme {
  padding?: string
  label?: {
    color?: string
    textTransform?: string
    fontSize?: string
    fontWeight?: string
  }

  value?: {
    color?: string
    textTransform?: string
    fontSize?: string
    fontWeight?: string
  }
}
