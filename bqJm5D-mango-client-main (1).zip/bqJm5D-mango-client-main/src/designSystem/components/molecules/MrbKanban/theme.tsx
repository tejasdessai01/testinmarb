export interface MrbKanbanTheme {
  background?: string
  column?: {
    background?: string
    border?: string
  }
}
