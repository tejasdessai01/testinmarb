export interface FormSettings {
  emitStyle: 'onChange' | 'onBlur'
}

export * from './manager'
