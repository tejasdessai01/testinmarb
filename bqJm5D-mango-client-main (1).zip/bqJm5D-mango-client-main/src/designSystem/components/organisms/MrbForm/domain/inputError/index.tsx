export interface InputError {
  key: string
  message: string
}
