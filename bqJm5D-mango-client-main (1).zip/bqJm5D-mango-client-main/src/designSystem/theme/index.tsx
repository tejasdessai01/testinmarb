import { ThemeUltimate } from './theme.ultimate'
import { ThemeType } from './type'

export const Theme: ThemeType = ThemeUltimate
