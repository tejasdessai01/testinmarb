

import { User } from "../user"

import { Transaction } from "../transaction"

export class Account {

id: string

balance?: number

accountType?: string

userId: string

user?: User

dateCreated: string

dateDeleted: string

dateUpdated: string

transactions?: Transaction[]

}
