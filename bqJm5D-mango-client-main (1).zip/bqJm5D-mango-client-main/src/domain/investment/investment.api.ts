import { HttpService } from '../../core/http'
import { ApiHelper } from '../helpers/api.helper'
import { Investment } from './investment.model'

export namespace InvestmentApi {
  export function findMany(
    queryOptions?: ApiHelper.QueryOptions<Investment>,
  ): Promise<Investment[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/investments${buildOptions}`)
  }

  export function findOne(
    investmentId: string,
    queryOptions?: ApiHelper.QueryOptions<Investment>,
  ): Promise<Investment> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/investments/${investmentId}${buildOptions}`,
    )
  }

  export function createOne(
    investment: Partial<Investment>,
  ): Promise<Investment> {
    return HttpService.api.post(`/v1/investments`, investment)
  }

  export function updateOne(
    investmentId: string,
    values: Partial<Investment>,
  ): Promise<Investment> {
    return HttpService.api.patch(
      `/v1/investments/${investmentId}`,
      values,
    )
  }

  export function deleteOne(investmentId: string): Promise<void> {
    return HttpService.api.delete(`/v1/investments/${investmentId}`)
  }

export function findManyByUserId(
    userId: string,
    queryOptions?: ApiHelper.QueryOptions<Investment>,
  ): Promise<Investment[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/users/user/${userId}/investments${buildOptions}`,
    )
  }

  export function createOneByUserId(
    userId: string,
    values: Partial<Investment>,
  ): Promise<Investment> {
    return HttpService.api.post(
      `/v1/users/user/${userId}/investments`,
      values,
    )
  }

}
