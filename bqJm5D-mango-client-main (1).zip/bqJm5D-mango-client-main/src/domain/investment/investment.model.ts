

import { User } from "../user"

import { Stock } from "../stock"

export class Investment {

id: string

investmentType?: string

balance?: number

userId: string

user?: User

dateCreated: string

dateDeleted: string

dateUpdated: string

stocks?: Stock[]

}
