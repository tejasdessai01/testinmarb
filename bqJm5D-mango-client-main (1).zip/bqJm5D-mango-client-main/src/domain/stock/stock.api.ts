import { HttpService } from '../../core/http'
import { ApiHelper } from '../helpers/api.helper'
import { Stock } from './stock.model'

export namespace StockApi {
  export function findMany(
    queryOptions?: ApiHelper.QueryOptions<Stock>,
  ): Promise<Stock[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/stocks${buildOptions}`)
  }

  export function findOne(
    stockId: string,
    queryOptions?: ApiHelper.QueryOptions<Stock>,
  ): Promise<Stock> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/stocks/${stockId}${buildOptions}`,
    )
  }

  export function createOne(
    stock: Partial<Stock>,
  ): Promise<Stock> {
    return HttpService.api.post(`/v1/stocks`, stock)
  }

  export function updateOne(
    stockId: string,
    values: Partial<Stock>,
  ): Promise<Stock> {
    return HttpService.api.patch(
      `/v1/stocks/${stockId}`,
      values,
    )
  }

  export function deleteOne(stockId: string): Promise<void> {
    return HttpService.api.delete(`/v1/stocks/${stockId}`)
  }

export function findManyByInvestmentId(
    investmentId: string,
    queryOptions?: ApiHelper.QueryOptions<Stock>,
  ): Promise<Stock[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/investments/investment/${investmentId}/stocks${buildOptions}`,
    )
  }

  export function createOneByInvestmentId(
    investmentId: string,
    values: Partial<Stock>,
  ): Promise<Stock> {
    return HttpService.api.post(
      `/v1/investments/investment/${investmentId}/stocks`,
      values,
    )
  }

}
