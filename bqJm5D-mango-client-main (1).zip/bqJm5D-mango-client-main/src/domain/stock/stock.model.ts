

import { Investment } from "../investment"

export class Stock {

id: string

symbol?: string

unitValue?: number

quantity?: number

investmentId: string

investment?: Investment

dateCreated: string

dateDeleted: string

dateUpdated: string

}
