import { HttpService } from '../../core/http'
import { ApiHelper } from '../helpers/api.helper'
import { Transaction } from './transaction.model'

export namespace TransactionApi {
  export function findMany(
    queryOptions?: ApiHelper.QueryOptions<Transaction>,
  ): Promise<Transaction[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(`/v1/transactions${buildOptions}`)
  }

  export function findOne(
    transactionId: string,
    queryOptions?: ApiHelper.QueryOptions<Transaction>,
  ): Promise<Transaction> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/transactions/${transactionId}${buildOptions}`,
    )
  }

  export function createOne(
    transaction: Partial<Transaction>,
  ): Promise<Transaction> {
    return HttpService.api.post(`/v1/transactions`, transaction)
  }

  export function updateOne(
    transactionId: string,
    values: Partial<Transaction>,
  ): Promise<Transaction> {
    return HttpService.api.patch(
      `/v1/transactions/${transactionId}`,
      values,
    )
  }

  export function deleteOne(transactionId: string): Promise<void> {
    return HttpService.api.delete(`/v1/transactions/${transactionId}`)
  }

export function findManyByAccountId(
    accountId: string,
    queryOptions?: ApiHelper.QueryOptions<Transaction>,
  ): Promise<Transaction[]> {
    const buildOptions = ApiHelper.buildQueryOptions(queryOptions)

    return HttpService.api.get(
      `/v1/accounts/account/${accountId}/transactions${buildOptions}`,
    )
  }

  export function createOneByAccountId(
    accountId: string,
    values: Partial<Transaction>,
  ): Promise<Transaction> {
    return HttpService.api.post(
      `/v1/accounts/account/${accountId}/transactions`,
      values,
    )
  }

}
