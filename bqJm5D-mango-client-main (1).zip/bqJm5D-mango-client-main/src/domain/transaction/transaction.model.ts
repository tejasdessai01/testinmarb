

import { Account } from "../account"

export class Transaction {

id: string

amount?: number

transactionType?: string

description?: string

date?: string

accountId: string

account?: Account

dateCreated: string

dateDeleted: string

dateUpdated: string

}
