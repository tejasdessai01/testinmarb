

import { Notification } from "../notification"

import { Account } from "../account"

import { Investment } from "../investment"

export enum UserStatus {
  CREATED = 'CREATED',
  VERIFIED = 'VERIFIED',
}
export class User {
  id: string

  email: string

  status: UserStatus

  name: string

  pictureUrl: string

  password: string

  dateCreated: string

  dateUpdated: string

  notifications?: Notification[]

accounts?: Account[]

investments?: Investment[]

}
