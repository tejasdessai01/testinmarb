import { MrbNavbar } from '@/designSystem'

export function ApplicationLeftbar() {
  return (
    <MrbNavbar direction="vertical">
      
    </MrbNavbar>
  )
}
