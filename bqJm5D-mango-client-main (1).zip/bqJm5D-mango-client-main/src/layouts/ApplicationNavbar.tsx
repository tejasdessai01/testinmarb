import { RouterObject } from '@/core/router'
import { useCoreStore } from '@/core/store'
import { MrbAvatar, MrbBadge, MrbIcon, MrbNavbar, MrbRow, MrbTag } from '@/designSystem'
import { useAuthentication } from '@/modules/authentication'
import React from 'react'

export const ApplicationNavbar: React.FC = () => {
  const oneLetterLogoName = 'Mango'.charAt(0).toUpperCase()

  const authentication = useAuthentication()

  const store = useCoreStore()

  const user = authentication.user

  const countNotifications = store.notifications.length

  return (
    <MrbNavbar>
      <MrbNavbar.Logo
        to={RouterObject.route.HOME}
        urlLogo="https://marblism-dashboard-api--production-public.s3.us-west-1.amazonaws.com/bqJm5D-mango-pKbM"
        className="mr-5"
      >
        {oneLetterLogoName}
      </MrbNavbar.Logo>

      <MrbRow className="mrb-fill-flex" gap={1}>

<MrbNavbar.Link to="/dashboard">
          Dashboard
        </MrbNavbar.Link>

<MrbNavbar.Link to="/transactions">
          Transactions
        </MrbNavbar.Link>

<MrbNavbar.Link to="/investments">
          Investments
        </MrbNavbar.Link>

<MrbNavbar.Link to="/stocks">
          My Stocks
        </MrbNavbar.Link>

<MrbNavbar.Link to="/account/create">
          Create Account
        </MrbNavbar.Link>

<MrbNavbar.Link to="/transaction/create">
          New Transaction
        </MrbNavbar.Link>

<MrbNavbar.Link to="/investment/create">
          Add Investment
        </MrbNavbar.Link>

<MrbNavbar.Link to="/stock/create">
          Add New Stock
        </MrbNavbar.Link>

</MrbRow>

      {store.isAdmin && (
        <MrbNavbar.Item>
          <MrbTag variant="primary">
            <MrbIcon name="user-star-fill" className="mr-1" />
            Admin
          </MrbTag>
        </MrbNavbar.Item>
      )}

      <MrbNavbar.Link to={RouterObject.route.NOTIFICATIONS}>
        <MrbBadge content={countNotifications} variant="danger">
          <MrbIcon name="notification-2" />
        </MrbBadge>
      </MrbNavbar.Link>

      <MrbNavbar.Avatar to={RouterObject.route.PROFILE}>
        <MrbAvatar src={user?.pictureUrl}>{user?.name}</MrbAvatar>
      </MrbNavbar.Avatar>
    </MrbNavbar>
  )
}
